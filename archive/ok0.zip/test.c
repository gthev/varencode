#include "printbin.h"
#include "varencode.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
	unsigned int data[3] = {83, 8277, 15};
	unsigned int res[3] = {0, 0, 0};

	stream_bin((unsigned char*)data, 3*sizeof(unsigned int));
	printf("\n");
	
	struct varencode_ctx ctx = {(void*)data, (void*)res, 3, sizeof(unsigned int)};
	int rescode = varencode(ctx);
	printf("%d\n", rescode);
	
	if(rescode <= 0)
		return -1;

	stream_bin((unsigned char*)ctx.res, rescode);
	printf("\n");

	struct vardecode_ctx ctx_de = {(void*)ctx.res,(void*)data, rescode, 3, sizeof(unsigned int)};
	rescode = vardecode(ctx_de);
	printf("%d\n", rescode);
	if(rescode < 0)
		return -1;

	stream_bin((unsigned char*)ctx_de.decoded, 3*sizeof(unsigned int));
	printf("\n");
	return 0;
}
