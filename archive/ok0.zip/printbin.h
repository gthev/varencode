void char_bin(unsigned char n);

void short_bin(unsigned short n);

void int_bin(unsigned int n);

void stream_bin(unsigned char *p, int length);

